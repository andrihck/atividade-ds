import './App.css'
import Banner from './Componentes/Banner'
import Header from './Componentes/Header'
import Sobre from './Componentes/Sobre'

function App() {
  

  return (
    
      <div>
        <Banner/>
        <Header/>
        <Sobre/>
      </div>
        
    
  )
}

export default App
