export default function Banner(){
    return(
        <section className="Banner">
            <img id="gatinhosFofinhos" src='gatinho1.jpg'></img>
            <img id="gatinhos1" src='gatinho2.jpg'></img>    
            <img id="gatinhos2" src='gatinho3.jfif'></img>
            <img id="gatinhos3" src='gatinho4.jpg'></img>
            <img id="gatinhos4" src='gatinho5.jpg'></img>
            <img id="gatinhos5" src='gatinho6.webp'></img>
        </section>
    )
}