export default function sobre(){
    return(
        <section className="sobre">
            
        </section>
        
    )
}